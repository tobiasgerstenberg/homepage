This folder contains the data of Experiments 1 and 2 as reported in: 

Gerstenberg, T., Goodman, N. D., Lagnado, D. A. & Tenenbaum, J. B. (2015). How, whether, why: Causal judgments as counterfactual contrasts. In Proceedings of the 37th Annual Conference of the Cognitive Science Society

For any questions, please feel free to contact me at: tger@mit.edu

