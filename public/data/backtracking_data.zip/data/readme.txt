The data files contain the empirical data from the following paper: 

Gerstenberg, T., Bechlivanidis, C. & Lagnado, D. A. (2013). Back on track: Backtracking in counterfactual reasoning. In M. Knauff, M. Pauen, N. Sebanz, & I. Wachsmuth (Eds.), Proceedings of the 35th Annual Conference of the Cognitive Science Society. Austin, TX: Cognitive Science Society. 

The stimuli used in the experiment can be accessed here: 
http://www.ucl.ac.uk/lagnado-lab/experiments/demos/backtracking_demo.html

Please contact Tobias Gerstenberg in case you have any questions concerning the data: tger@mit.edu

Thanks! 

