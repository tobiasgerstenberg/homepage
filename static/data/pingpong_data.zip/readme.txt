The data files contain the empirical data from the following paper: 

Gerstenberg, T. & Goodman, N. D. (2012). Ping Pong in Church: Productive use of concepts in human probabilistic inference. In N. Miyake, D. Peebles, & R. P. Cooper (Eds.), Proceedings of the 34th Annual Conference of the Cognitive Science Society. Austin, TX: Cognitive Science Society.

Data formats are: .xlsx, .xls and .csv (one .csv file for each worksheet)  

Please contact Tobias Gerstenberg in case you have any questions concerning the data: t.gerstenberg@ucl.ac.uk 

Thanks! 

