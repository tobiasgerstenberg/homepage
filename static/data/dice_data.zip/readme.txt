The data files contain the empirical data from the following paper: 

Gerstenberg, T., Lagnado, D. A. & Kareev, Y. (2010). The dice are cast: The role of intended versus actual contributions in responsibility attribution. In S. Ohlsson & R. Catrambone (Eds.), Proceedings of the 32nd Annual Conference of the Cognitive Science Society. Austin, TX: Cognitive Science Society.

Data formats are: .xlsx, .xls and .csv (one .csv file for each worksheet)  

Please contact Tobias Gerstenberg in case you have any questions concerning the data: t.gerstenberg@ucl.ac.uk 

Thanks! 

