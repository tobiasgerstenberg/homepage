This folder contains the data of the Experiment reported in: 

Gerstenberg, T., Halpern, J. Y. & Tenenbaum, J. B. (2015). Responsibility judgments in voting scenarios. In Proceedings of the 37th Annual Conference of the Cognitive Science Society.

• "voting_data.csv" contains the data 
• "voting_patterns_three.csv" contains the patterns of votes for each of the different situations involving three committee members (as indicated in the column "trial" in "voting_data.csv")
• "voting_patterns_five.csv" contains the patterns of votes for each of the different situations involving five committee members (as indicated in the column "trial" in "voting_data.csv")

Column legend for the tables with the patterns: 
• p1 - p5 = party affiliation: 0 = opposite party, 1 = same party that supports the policy 
• v1 - v5 = vote of each party member: 0 = against policy, 1 = for policy 

For any questions, please feel free to contact me at: tger@mit.edu

