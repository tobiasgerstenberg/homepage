The data files contain the empirical data from the following paper: 

Gerstenberg, T., Goodman, N. D., Lagnado, D. A. & Tenenbaum, J. B. (2012). Noisy Newtons: Unifying process and dependency accounts of causal attribution. In N. Miyake, D. Peebles, & R. P. Cooper (Eds.), Proceedings of the 34th Annual Conference of the Cognitive Science Society. Austin, TX: Cognitive Science Society.

Data formats are: .xlsx, and .xls 

The stimuli used in the experiment can be accessed here: 
http://www.ucl.ac.uk/lagnado-lab/experiments/demos/physicsdemo.html

Please contact Tobias Gerstenberg in case you have any questions concerning the data: t.gerstenberg@ucl.ac.uk 

Thanks! 

