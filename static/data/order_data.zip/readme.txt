The data files contain the empirical data from the following paper: 

Gerstenberg, T., Lagnado, D. A, Speekenbrink, M. & Cheung, C. (submitted). Rational order effects in responsibility attributions. In L. Carlson, C. Hölscher, & T. Shipley (Eds.), Proceedings of the 33rd Annual Conference of the Cognitive Science Society. Austin, TX: Cognitive Science Society.

Data formats are: .xlsx, .xls and .csv (one .csv file for each worksheet)  

Please contact Tobias Gerstenberg in case you have any questions concerning the data: t.gerstenberg@ucl.ac.uk 

Thanks! 

